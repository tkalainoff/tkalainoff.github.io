var angle = 0;	// initialize angle variable
var scalar = 50;  // set the radius of circle
var startX = 100;	// set the x-coordinate for the circle center
var startY = 100;	// set the y-coordinate for the circle center

function setup() {
  createCanvas(400, 400);
	background(255);
  angleMode(DEGREES);	// change the angle mode from radians to degrees
}

function draw() {
  var x = startX + scalar * cos(angle);
  var y = startY + scalar * sin(angle);
  
  ellipse(x, y, 8);
  
  angle++;	// increment angle for the next frame
}